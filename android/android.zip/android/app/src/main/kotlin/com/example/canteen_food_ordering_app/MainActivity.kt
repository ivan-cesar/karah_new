package com.propulse.karah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
